﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media.Effects;
using Tortoise_Record.View.Dialogs;

namespace Tortoise_Record.Units
{
    public class CustomMessageBoxController
    {

        public enum Buttons
        {
            Yes_No,
            OK
        }

        public static string Show(string text)
        {
            return Show(text, Buttons.OK);
        }

        public static string Show(string Text, Buttons buttons)
        {
            CustomMessageBox messageBox = new CustomMessageBox(Text, buttons);
            messageBox.Show();
            return messageBox.ReturnString;
        }
        
        public static string ShowDialog(string Text)
        {
            return ShowDialog(Text, Buttons.OK);
        }

        public static string ShowDialog(string Text, Buttons buttons)
        {
            ShowBlurEffectAllWindow();
            CustomMessageBox messageBox = new CustomMessageBox(Text, buttons);
            messageBox.ShowDialog();
            StopBlurEffectAllWindow();
            return messageBox.ReturnString;
        }

        public static string ShowShortNotification(string text)
        {
            ShortNotification shortNotification = new ShortNotification(text);
            shortNotification.Show();
            return "1";
        }

        public static string ShowDialogShortNotification(string text)
        {
            ShowBlurEffectAllWindow();
            ShortNotification shortNotification = new ShortNotification(text);
            shortNotification.ShowDialog();
            StopBlurEffectAllWindow();
            return "1";
        }

        static BlurEffect MyBlur = new BlurEffect();
        public static void ShowBlurEffectAllWindow()
        {
            MyBlur.Radius = 20;
            foreach (Window window in Application.Current.Windows)
                window.Effect = MyBlur;
        }

        public static void StopBlurEffectAllWindow()
        {
            MyBlur.Radius = 0;
        }

        class CloseController
        {
            public static void AllShortNotifications()
            {
                foreach (ShortNotification window in Application.Current.Windows.OfType<ShortNotification>())
                    window.FastClose();
                while (Application.Current.Windows.OfType<ShortNotification>().Count() > 0) { }
            }

            public static void AllMessageBoxes()
            {
                foreach (CustomMessageBox window in Application.Current.Windows.OfType<CustomMessageBox>())
                    window.Close();
                while (Application.Current.Windows.OfType<CustomMessageBox>().Count() > 0) { }
            }

            public static void AllMessages()
            {
                AllShortNotifications();
                AllMessageBoxes();
            }
        }
    }


}
