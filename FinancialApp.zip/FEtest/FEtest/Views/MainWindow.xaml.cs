﻿using FEtest.API;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Tortoise_Record.Units;

namespace FEtest
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window,IApiCallback
    {
        public Brush colorConverter(string hex)
        {
            var converter = new System.Windows.Media.BrushConverter();
            var brush = (Brush)converter.ConvertFromString(hex);
            return brush;
        }
        public MainWindow()
        {
            InitializeComponent();
        }

        public void hideLoading()
        {
            loader.Visibility = Visibility.Hidden;
        }

        public void onErrorResult(string message)
        {
            CustomMessageBoxController.ShowDialog(message, CustomMessageBoxController.Buttons.OK);

        }
        public void onGetResult(string result)
        {
            try 
            {
                    dataGridPrikaz.ItemsSource = "";
                    API.JsonSerializer.Serializer(result);
                    dataGridPrikaz.ItemsSource = API.JsonSerializer.data;
                    dataGridPrikaz.Visibility = Visibility.Visible;


            }
            catch
            {
                CustomMessageBoxController.ShowDialog("Trazeni simbol ne postoji.", CustomMessageBoxController.Buttons.OK);
                dataGridPrikaz.Visibility = Visibility.Hidden;
            }
        }

        public void showLoading()
        {
            loader.Visibility = Visibility.Visible;
        }

        private async void Button_ClickAsync(object sender, RoutedEventArgs e)
        {


            APIHelper helper = new APIHelper(this);
            helper.GetAll(tbPretraga.Text);
        }

        private void Grid_MouseDown(object sender, MouseButtonEventArgs e)
        {
            prozor.DragMove();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Button_MouseEnter(object sender, MouseEventArgs e)
        {
            closeIkonica.Foreground = Brushes.Black;
        }

        private void btnClose_MouseLeave(object sender, MouseEventArgs e)
        {
            closeIkonica.Foreground = Brushes.White;
        }

        
        private void btnFind_MouseEnter(object sender, MouseEventArgs e)
        {
            var color = colorConverter("#b20837");
            searchIcon.Foreground = color;
            FindTB.Foreground = color;
            btnFind.Background = Brushes.White;
            btnFind.BorderThickness = new Thickness(1, 1, 1, 1);
            btnFind.BorderBrush = color;

        }

        private void btnFind_MouseLeave(object sender, MouseEventArgs e)
        {
            var color = colorConverter("#b20837");
            searchIcon.Foreground = Brushes.White;
            FindTB.Foreground = Brushes.White;
            btnFind.Background = color;

        }

        private void tbPretraga_GotFocus(object sender, RoutedEventArgs e)
        {
            var color = colorConverter("#ffffff");

            tbPretraga.Text = "";
            tbPretraga.Foreground = color;
        }

        private void tbPretraga_LostFocus(object sender, RoutedEventArgs e)
        {
            if (tbPretraga.Text == "")
            {
                tbPretraga.Text = "Pretraga simbola...";
                tbPretraga.Foreground = Brushes.Gray;
            }


        }

        private void tbPretraga_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.Key == Key.Enter)
            {
                APIHelper helper = new APIHelper(this);
                helper.GetAll(tbPretraga.Text);
            }
        }

    }
}
