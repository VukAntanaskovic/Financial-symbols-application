﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Tortoise_Record.Units;

namespace Tortoise_Record.View.Dialogs
{

    public partial class CustomMessageBox : Window
    {
        public string ReturnString { get; set; }

        public CustomMessageBox(string Text)
        {
            InitializeComponent();

            txbText.Text = Text;
        }
        public CustomMessageBox(string Text, CustomMessageBoxController.Buttons buttons)
        {
            InitializeComponent();
            txbText.Text = Text;

            switch (buttons)
            {
                case CustomMessageBoxController.Buttons.OK:
                    btnOK.Visibility = Visibility.Visible;
                    break;
                case CustomMessageBoxController.Buttons.Yes_No:
                    btnYes.Visibility = Visibility.Visible;
                    btnNo.Visibility = Visibility.Visible;
                    break;
            }
        }

        private void GBar_MouseDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                DragMove(); // dozvoljava da windows bude pomeran 
            }
            catch { }
        }

        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            ReturnString = "-1";
            Close();
        }

        DoubleAnimation anim;
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            Closing -= Window_Closing;
            e.Cancel = true;
            anim = new DoubleAnimation(0, (Duration)TimeSpan.FromSeconds(0.3));
            anim.Completed += (s, _) => this.Close();
            this.BeginAnimation(UIElement.OpacityProperty, anim);
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Height = (txbText.LineCount * 42) + gBar.Height + 50; // podesavanje visine dialoga u odnosu na tekst i gBar
        }
        
        // Uid vraca, yes 1, no 0, ok 1
        private void btnReturnValue_Click(object sender, RoutedEventArgs e)
        {
            ReturnString = ((Button)sender).Uid.ToString();
            Close();
        }

    }
}
